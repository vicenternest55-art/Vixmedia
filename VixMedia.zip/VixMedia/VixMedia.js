// ====== SETTINGS ======
const WHATSAPP_NUMBER = "255617314014"; // 0617314014 -> wa.me uses international format (no 0, no +)
const BRAND_NAME = "VixMedia";

// Safety check
if (!WHATSAPP_NUMBER || WHATSAPP_NUMBER.length < 10) {
  console.warn("WhatsApp number seems invalid. Please set WHATSAPP_NUMBER correctly.");
}

// ====== THEME TOGGLE (Dark/Light) ======
const themeToggle = document.getElementById("themeToggle");
const themeIcon = themeToggle?.querySelector(".theme-icon");
const themeText = themeToggle?.querySelector(".theme-text");

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("vix_theme", theme);

  if (themeIcon) themeIcon.textContent = theme === "dark" ? "🌙" : "☀️";
  if (themeText) themeText.textContent = theme === "dark" ? "Dark" : "Light";
}

(function initTheme() {
  const saved = localStorage.getItem("vix_theme");
  // default dark
  applyTheme(saved || "dark");
})();

themeToggle?.addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme") || "dark";
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
});

// ====== NAV: mobile toggle ======
const navToggle = document.getElementById("navToggle");
const navMenu = document.getElementById("navMenu");

navToggle?.addEventListener("click", () => {
  const isOpen = navMenu.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", String(isOpen));
});

// Close menu after clicking a link (mobile)
document.querySelectorAll(".nav a.nav-link, .nav a.btn").forEach(a => {
  a.addEventListener("click", () => {
    navMenu.classList.remove("open");
    navToggle?.setAttribute("aria-expanded", "false");
  });
});

// ====== Active nav on scroll ======
const sections = ["services", "work", "process", "testimonials", "contact"]
  .map(id => document.getElementById(id))
  .filter(Boolean);

const navLinks = Array.from(document.querySelectorAll(".nav-link"));

function setActiveNav() {
  const y = window.scrollY + 120;
  let currentId = "top";

  for (const sec of sections) {
    const top = sec.offsetTop;
    const bottom = top + sec.offsetHeight;
    if (y >= top && y < bottom) currentId = sec.id;
  }

  navLinks.forEach(link => {
    const href = link.getAttribute("href") || "";
    link.classList.toggle("active", href === `#${currentId}`);
  });
}
window.addEventListener("scroll", setActiveNav);
setActiveNav();

// ====== Reveal on scroll ======
const revealEls = document.querySelectorAll(".reveal");
const io = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const delay = el.getAttribute("data-delay");
      if (delay) el.style.transitionDelay = `${delay}ms`;
      el.classList.add("show");
      io.unobserve(el);
    }
  });
}, { threshold: 0.12 });

revealEls.forEach(el => io.observe(el));

// ====== Footer year ======
document.getElementById("year").textContent = new Date().getFullYear();

// ====== WhatsApp link builder ======
function buildWhatsAppLink(text) {
  const msg = encodeURIComponent(text);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`;
}

function defaultWhatsAppMessage() {
  return `Hello ${BRAND_NAME}, naomba website.\n\nBusiness/Brand: \nPages needed: \nExample website (if any): \nTimeline: \nBudget (optional): \n\nSent from your website.`;
}

// Set WhatsApp links
const waFloat = document.getElementById("waFloat");
const waTop = document.getElementById("waLinkTop");

function updateWhatsAppLinks(customMessage) {
  const link = buildWhatsAppLink(customMessage || defaultWhatsAppMessage());
  if (waFloat) waFloat.href = link;
  if (waTop) waTop.href = link;
}
updateWhatsAppLinks();

// ====== Contact form validation + message copy ======
const form = document.getElementById("contactForm");
const toast = document.getElementById("toast");
const copyBtn = document.getElementById("copyMsgBtn");

function showToast(message, ok = true) {
  if (!toast) return;
  toast.style.display = "block";
  toast.textContent = message;
  toast.style.borderColor = ok ? "rgba(21,225,255,0.18)" : "rgba(255,120,120,0.35)";
  toast.style.background = ok ? "rgba(21,225,255,0.08)" : "rgba(255,120,120,0.10)";
  setTimeout(() => (toast.style.display = "none"), 4200);
}

function setError(id, message) {
  const el = document.querySelector(`small.error[data-for="${id}"]`);
  if (el) el.textContent = message || "";
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function buildMessageFromForm(fd) {
  const name = fd.get("name")?.toString().trim() || "";
  const email = fd.get("email")?.toString().trim() || "";
  const service = fd.get("service")?.toString().trim() || "";
  const budget = fd.get("budget")?.toString().trim() || "";
  const message = fd.get("message")?.toString().trim() || "";

  return `Hello ${BRAND_NAME},\n\nMy name is ${name}.\nEmail: ${email}\nService: ${service}\nBudget: ${budget || "Not specified"}\n\nProject Details:\n${message}\n\nSent from your website.`;
}

form?.addEventListener("submit", (e) => {
  e.preventDefault();

  ["name", "email", "service", "message"].forEach(k => setError(k, ""));

  const fd = new FormData(form);
  const name = fd.get("name")?.toString().trim() || "";
  const email = fd.get("email")?.toString().trim() || "";
  const service = fd.get("service")?.toString().trim() || "";
  const message = fd.get("message")?.toString().trim() || "";

  let ok = true;
  if (name.length < 2) { setError("name", "Please enter your full name."); ok = false; }
  if (!validateEmail(email)) { setError("email", "Please enter a valid email."); ok = false; }
  if (!service) { setError("service", "Please select a service."); ok = false; }
  if (message.length < 10) { setError("message", "Please add more details (at least 10 characters)."); ok = false; }

  if (!ok) {
    showToast("Fix the highlighted fields then try again.", false);
    return;
  }

  const waMessage = buildMessageFromForm(fd);
  updateWhatsAppLinks(waMessage);

  window.open(buildWhatsAppLink(waMessage), "_blank", "noopener");

  showToast("Message prepared. WhatsApp is opening...", true);
  form.reset();
});

copyBtn?.addEventListener("click", async () => {
  if (!form) return;
  const fd = new FormData(form);
  const text = buildMessageFromForm(fd);

  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied! Paste it on WhatsApp.", true);
    updateWhatsAppLinks(text);
  } catch (err) {
    showToast("Copy failed. Your browser may block clipboard.", false);
  }
});
